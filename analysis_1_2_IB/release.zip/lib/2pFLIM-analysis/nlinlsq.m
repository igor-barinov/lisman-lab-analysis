function [beta, residuals, J] = nlinlsq(x, y, weight, model, beta0)
    if (size(x, 1) ~= size(y, 1))
        error('Count mismatch between x and y');
    end
    if (size(beta0, 1) > 1)
        if (size(beta0, 2) > 1)
            beta0 = beta0(1, :);
        else
            beta0 = beta0';
        end
    end

    numInputs = size(x, 2);
    numVars = length(beta0);
    
    J = zeros(numInputs, numVars);
    beta = beta0;
    
    delta = 0.001;
    maxIter = 100;
    for i = 1:maxIter
        % Calculate residuals
        yFit = feval(model, x, beta);
        residuals = y - yFit;
        
        % Calculate Jacobion (J)
        dResid = diff(residuals) / delta;
        
        
        
        
        Jt = J';
        beta = beta + (Jt * J) \ Jt * residuals; 
    end
    
    % Calculate jacobian
    for r = 1:numInputs
        for c = 1:numVars
            % J(r,c) = dInput / dVar (beta0)
            
            resid = y - feval(model, beta0
            
            diff(
        end
    end
    
end