function h_dragLSRoi_WindowButtonMotionFcn

global h_img

point1 = get(gca,'CurrentPoint');
UserData = get(gco,'UserData');
I = find(UserData.ROIHandles==gco);
UserData.roi_pos(I) = point1(1);
set(gco,'XData',[point1(1),point1(1)],'UserData',UserData);
