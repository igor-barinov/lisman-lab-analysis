classdef ROIFileType < uint8
    enumeration
        Raw         (1)
        FLImage     (2)
        Prepared    (3)
        Averaged    (4)
        None        (0)
    end
end