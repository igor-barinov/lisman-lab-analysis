function h_dragRoiText

UserData = get(gco,'UserData');
set(gcf,'CurrentObject',UserData.ROIhandle);
h_dragroi;