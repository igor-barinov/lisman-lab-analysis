function h_dragRoiText2

UserData = get(gco,'UserData');
set(gcf,'CurrentObject',UserData.ROIhandle);
h_dragRoi2;