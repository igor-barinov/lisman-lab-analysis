function h_dragTracingMarkText

UserData = get(gco,'UserData');
set(gcf,'CurrentObject',UserData.markHandle);
h_dragTracingMark;