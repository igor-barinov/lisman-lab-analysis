function h_makeBGRoi2(shape,Roi_size)

if ~(exist('shape')==1)|isempty(shape)
    shape = 'round';
end

if ~(exist('Roi_size')==1)|isempty(Roi_size)
    Roi_size = 20;
end

% axes(h_findobj('Tag','spc_IntensityAxes'));
% if strcmp(get(gca,'Tag'),'spc_IntensityAxes')
    switch lower(shape)
        case {'round'}
            waitforbuttonpress;
            point1 = get(gca,'CurrentPoint');    % button down detected
            finalRect = rbbox;                   % return figure units
            point2 = get(gca,'CurrentPoint');    % button up detected
            point1 = point1(1,1:2);              % extract x and y
            point2 = point2(1,1:2);
            p1 = min(point1,point2);             % calculate locations
            offset = abs(point1-point2);
            if offset(1)<2&offset(2)<2
                offset = [Roi_size, Roi_size];
            end
            ROI = [point1, offset(1), offset(2)];
            theta = [0:1/40:1]*2*pi;
            xr = ROI(3)/2;
            yr = ROI(4)/2;
            xc = ROI(1) + ROI(3)/2;
            yc = ROI(2) + ROI(4)/2;
            UserData.roi.xi = sqrt(xr^2*yr^2./(xr^2*sin(theta).^2 + yr^2*cos(theta).^2)).*cos(theta) + xc;
            UserData.roi.yi = sqrt(xr^2*yr^2./(xr^2*sin(theta).^2 + yr^2*cos(theta).^2)).*sin(theta) + yc;
        case {'square'}
            waitforbuttonpress;
            point1 = get(gca,'CurrentPoint');    % button down detected
            finalRect = rbbox;                   % return figure units
            point2 = get(gca,'CurrentPoint');    % button up detected
            point1 = point1(1,1:2);              % extract x and y
            point2 = point2(1,1:2);
            p1 = min(point1,point2);             % calculate locations
            offset = abs(point1-point2);
            if offset(1)<2&offset(2)<2
                offset = [Roi_size, Roi_size];
            end
            UserData.roi.xi = [p1(1),p1(1)+offset(1),p1(1)+offset(1),p1(1),p1(1)];
            UserData.roi.yi = [p1(2),p1(2),p1(2)+offset(2),p1(2)+offset(2),p1(2)];
        case {'roipoly'}
            waitforbuttonpress;
            [BW,UserData.roi.xi,UserData.roi.yi] = roipoly;
        otherwise
            return;
    end    
    i = findobj(h_findobj(gcf,'Tag','HBGROI'));
    i_UserData = get(i,'UserData');
    if isfield(i_UserData,'texthandle')
        delete(i_UserData.texthandle);
        delete(i);
    end
    hold on;
    h = plot(UserData.roi.xi,UserData.roi.yi,'m-');
    set(h,'ButtonDownFcn', 'h_dragRoi2', 'Tag', 'HBGROI', 'Color','red', 'EraseMode','xor');
    hold off;
    x = (min(UserData.roi.xi) + max(UserData.roi.xi))/2;
    y = (min(UserData.roi.yi) + max(UserData.roi.yi))/2;
    UserData.texthandle = text(x,y,'BG','HorizontalAlignment',...
        'Center','VerticalAlignment','Middle', 'Color','red','EraseMode','xor','ButtonDownFcn', 'h_dragRoiText2');
    UserData.number = 'BG';
    UserData.ROIhandle = h;
    UserData.timeLastClick = clock;
    set(h,'UserData',UserData);
    set(UserData.texthandle,'UserData',UserData);
% end
