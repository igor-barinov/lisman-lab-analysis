function h_selectCurrentMontage

h = h_findobj('Tag','h_imstackMontage');
set(h,'Selected','off');
set(gcf,'Selected','on');