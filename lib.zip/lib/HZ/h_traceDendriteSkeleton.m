function h_traceDendriteSkeleton

global h_img;

handles = h_img.currentHandles;
