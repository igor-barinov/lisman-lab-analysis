function h_imstack_WindowButtonUpFcn

global h_img

h_img.temp.ButtonUp = 1;