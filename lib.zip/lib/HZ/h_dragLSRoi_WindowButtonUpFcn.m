function h_dragLSRoi_WindowButtonUpFcn

global h_img
set(h_img.currentHandles.h_imstack,'WindowButtonMotionFcn','', 'WindowButtonUpFcn', '');
