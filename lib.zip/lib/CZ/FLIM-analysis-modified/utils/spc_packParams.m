function [beta] = spc_packParams(pop1, tau1, pop2, tau2, tau_d, tau_g)
    beta = [pop1, tau1, pop2, tau2, tau_d, tau_g];
end