function spc_drawAll
%Fig2 = lifetime in ROI.

%set(gui.spc.figure.projectImage, 'CData', spc.project);

spc_drawLifetimeMap;
spc_drawLifetime;