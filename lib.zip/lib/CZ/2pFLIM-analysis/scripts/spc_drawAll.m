function spc_drawAll()
    spc_drawLifetimeMap();
    spc_drawLifetime();
end