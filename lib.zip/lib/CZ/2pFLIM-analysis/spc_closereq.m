function spc_closereq
global spcs
global spc
global gui

spcs = [];
spc = [];
closereq;