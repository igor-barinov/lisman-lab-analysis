function spc_drawProject;

global spc

if (spc.switches.imagemode == 0);
    return;
end;
