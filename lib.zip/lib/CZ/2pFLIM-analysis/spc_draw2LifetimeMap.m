function spc_draw2LifetimeMap
global spc

