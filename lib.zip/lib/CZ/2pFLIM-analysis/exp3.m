function y=exp2(beta0, x)
y=exp(-x/beta0(2))*beta0(1);
%w=max(x);
%square1 = rectpuls(x-beta0(3)-w/2, w);
%y =y.*square1;
