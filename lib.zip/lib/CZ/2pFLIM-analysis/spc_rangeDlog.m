function spc_rangeDlog
global spc
handle = guihandles(twodialog);
set(handle.upper, 'String', num2str(spc.switches.lifetime_limit(2)));
set(handle.lower, 'String', num2str(spc.switches.lifetime_limit(1)));
