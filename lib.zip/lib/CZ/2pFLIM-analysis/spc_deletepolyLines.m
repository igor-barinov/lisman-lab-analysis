function spc_deletepolyLines;
global spc;
global gui;


delete(findobj('Tag', 'poly'));


