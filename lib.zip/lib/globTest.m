function globTest()
    a = 5;
end