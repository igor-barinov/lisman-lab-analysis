function FLIManalysis
spc_drawInit;
%h_imstack
%n_thresholds