function [format] = precision_format(value)
    min = value / 1000;
end