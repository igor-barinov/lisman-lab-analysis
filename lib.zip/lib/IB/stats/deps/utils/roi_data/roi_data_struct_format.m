function [fields] = roi_data_struct_format()
    fields = {'time', 'int', 'red', '[lifetime]'};
end