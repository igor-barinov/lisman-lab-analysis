function [fields] = avg_data_struct_format()
    fields = {'time', 'int -> {avg, normAvg}', 'red -> {avg, normAvg}', '[lifetime -> {avg, normAvg}]'};
end