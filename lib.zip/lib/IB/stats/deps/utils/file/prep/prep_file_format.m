function [fields] = prep_file_format()
    fields = {'rawData', 'prepData', 'info'};
end