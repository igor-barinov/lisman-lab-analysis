function [fields] = exp_info_struct_format()
    fields = {'numROI', 'dnaType', 'solutions'};
end