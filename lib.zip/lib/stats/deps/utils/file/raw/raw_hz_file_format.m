function [fields] = raw_hz_file_format()
    fields = {'Aout -> {red, green, timestr}'};
end