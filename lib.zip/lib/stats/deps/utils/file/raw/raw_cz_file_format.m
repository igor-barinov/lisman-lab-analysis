function [fields] = raw_cz_file_format(expName)
    fields = {[expName, ' -> {time, tau_m, mean_int, red_mean}']};
end