function [fields] = raw_cz_struct_format()
    fields = {'roiData -> {time, tau_m, mean_int, read_mean}'};
end